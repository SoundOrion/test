# C# RabbitMQ sample

RabbitMQ が minikube 上の `rabbitmq` namespace に起動済みである前提の C# publish / consume サンプルです。

接続先:

```text
rabbitmq.rabbitmq.svc.cluster.local:5672
```

## RabbitMQ password secret 作成

`secretKeyRef` は同じ namespace の Secret しか参照できないため、RabbitMQ password を `app-sample` namespace にコピーします。

```powershell
$APP_NS="app-sample"

& $KUBECTL --kubeconfig $KUBECONFIG_PATH create namespace $APP_NS --dry-run=client -o yaml `
  | & $KUBECTL --kubeconfig $KUBECONFIG_PATH apply -f -

$RABBITMQ_PASSWORD_B64=(& $KUBECTL --kubeconfig $KUBECONFIG_PATH get secret -n rabbitmq rabbitmq `
  -o jsonpath="{.data.rabbitmq-password}")

$RABBITMQ_PASSWORD=[System.Text.Encoding]::UTF8.GetString(
  [System.Convert]::FromBase64String($RABBITMQ_PASSWORD_B64)
)

& $KUBECTL --kubeconfig $KUBECONFIG_PATH create secret generic rabbitmq-client-secret `
  -n $APP_NS `
  --from-literal=RABBITMQ_PASSWORD=$RABBITMQ_PASSWORD `
  --dry-run=client -o yaml `
  | & $KUBECTL --kubeconfig $KUBECONFIG_PATH apply -f -
```

## build / load

```powershell
docker build -t csharp-rabbitmq-sample:local .
..\scripts\docker-save-load-to-minikube.ps1 -Image csharp-rabbitmq-sample:local
```

## apply

```powershell
& $KUBECTL --kubeconfig $KUBECONFIG_PATH apply -f ..\k8s\namespace.yaml
& $KUBECTL --kubeconfig $KUBECONFIG_PATH apply -f .\k8s\consumer-deployment.yaml

& $KUBECTL --kubeconfig $KUBECONFIG_PATH delete job -n app-sample csharp-rabbitmq-publisher --ignore-not-found
& $KUBECTL --kubeconfig $KUBECONFIG_PATH apply -f .\k8s\publisher-job.yaml
```

## logs

```powershell
& $KUBECTL --kubeconfig $KUBECONFIG_PATH logs -n app-sample deploy/csharp-rabbitmq-consumer -f
& $KUBECTL --kubeconfig $KUBECONFIG_PATH logs -n app-sample job/csharp-rabbitmq-publisher
```
