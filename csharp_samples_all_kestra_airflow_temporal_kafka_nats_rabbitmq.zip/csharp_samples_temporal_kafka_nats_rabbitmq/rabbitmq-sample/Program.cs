using System.Text;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;

using var cts = new CancellationTokenSource();
Console.CancelKeyPress += (_, e) =>
{
    e.Cancel = true;
    cts.Cancel();
};

var mode = Env("RABBITMQ_MODE", "publish").ToLowerInvariant();
Console.WriteLine($"RABBITMQ_MODE={mode}");

switch (mode)
{
    case "publish":
        await PublishAsync(cts.Token);
        break;

    case "consume":
        await ConsumeAsync(cts.Token);
        break;

    default:
        throw new InvalidOperationException($"Unknown RABBITMQ_MODE: {mode}");
}

static async Task PublishAsync(CancellationToken ct)
{
    var queue = Env("RABBITMQ_QUEUE", "test-queue");

    await using var connection = await CreateConnectionAsync();
    await using var channel = await connection.CreateChannelAsync(cancellationToken: ct);

    await channel.QueueDeclareAsync(
        queue: queue,
        durable: true,
        exclusive: false,
        autoDelete: false,
        arguments: null,
        cancellationToken: ct
    );

    var message = Env("RABBITMQ_MESSAGE", $"hello from C# RabbitMQ at {DateTimeOffset.UtcNow:O}");
    var body = Encoding.UTF8.GetBytes(message);

    await channel.BasicPublishAsync(
        exchange: "",
        routingKey: queue,
        body: body,
        cancellationToken: ct
    );

    Console.WriteLine($"RabbitMQ published: queue={queue}, message={message}");
}

static async Task ConsumeAsync(CancellationToken ct)
{
    var queue = Env("RABBITMQ_QUEUE", "test-queue");

    await using var connection = await CreateConnectionAsync();
    await using var channel = await connection.CreateChannelAsync(cancellationToken: ct);

    await channel.QueueDeclareAsync(
        queue: queue,
        durable: true,
        exclusive: false,
        autoDelete: false,
        arguments: null,
        cancellationToken: ct
    );

    var consumer = new AsyncEventingBasicConsumer(channel);
    consumer.ReceivedAsync += async (_, ea) =>
    {
        var message = Encoding.UTF8.GetString(ea.Body.ToArray());
        Console.WriteLine($"RabbitMQ received: queue={queue}, message={message}");

        await channel.BasicAckAsync(
            deliveryTag: ea.DeliveryTag,
            multiple: false,
            cancellationToken: ct
        );
    };

    await channel.BasicConsumeAsync(
        queue: queue,
        autoAck: false,
        consumer: consumer,
        cancellationToken: ct
    );

    Console.WriteLine($"RabbitMQ consuming: queue={queue}");
    await Task.Delay(Timeout.InfiniteTimeSpan, ct);
}

static async Task<IConnection> CreateConnectionAsync()
{
    var host = Env("RABBITMQ_HOST", "rabbitmq.rabbitmq.svc.cluster.local");
    var port = int.Parse(Env("RABBITMQ_PORT", "5672"));
    var user = Env("RABBITMQ_USER", "user");
    var password = Env("RABBITMQ_PASSWORD", "");
    var vhost = Env("RABBITMQ_VHOST", "/");

    if (string.IsNullOrWhiteSpace(password))
    {
        Console.WriteLine("WARN: RABBITMQ_PASSWORD is empty. Set rabbitmq-client-secret in app-sample namespace.");
    }

    var factory = new ConnectionFactory
    {
        HostName = host,
        Port = port,
        UserName = user,
        Password = password,
        VirtualHost = vhost
    };

    Console.WriteLine($"RabbitMQ connecting: {user}@{host}:{port}{vhost}");
    return await factory.CreateConnectionAsync();
}

static string Env(string name, string fallback)
{
    var value = Environment.GetEnvironmentVariable(name);
    return string.IsNullOrWhiteSpace(value) ? fallback : value;
}
