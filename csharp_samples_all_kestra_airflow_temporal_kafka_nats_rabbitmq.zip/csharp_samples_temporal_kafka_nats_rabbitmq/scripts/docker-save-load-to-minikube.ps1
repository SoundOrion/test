param(
  [Parameter(Mandatory=$true)]
  [string]$Image
)

if (-not $BASE) {
  $BASE="C:\Users\Hatsuyama\Desktop\k8s\k8s-offline"
}

Write-Host "==== Loading image to minikube: $Image ====" -ForegroundColor Cyan

mkdir "$BASE\images" -Force | Out-Null

$safeName = [regex]::Replace($Image, "[/:@]", "_")
$tar = "$BASE\images\$safeName.tar"
$remote = "/home/docker/$safeName.tar"

docker image inspect $Image > $null 2>&1
if ($LASTEXITCODE -ne 0) {
  throw "Docker image not found in local Docker: $Image"
}

docker save $Image -o $tar
if ($LASTEXITCODE -ne 0) { throw "docker save failed: $Image" }

docker cp $tar "minikube:$remote"
if ($LASTEXITCODE -ne 0) { throw "docker cp failed: $tar" }

docker exec minikube docker load -i $remote
if ($LASTEXITCODE -ne 0) { throw "docker load in minikube failed: $Image" }

docker exec minikube rm $remote
Remove-Item $tar -Force

Write-Host "OK: $Image" -ForegroundColor Green
