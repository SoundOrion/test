$ErrorActionPreference = "Stop"

$ROOT = Split-Path -Parent $PSScriptRoot

$samples = @(
  @{ Dir = "temporal-sample"; Image = "csharp-temporal-sample:local" },
  @{ Dir = "kafka-sample";    Image = "csharp-kafka-sample:local" },
  @{ Dir = "nats-sample";     Image = "csharp-nats-sample:local" },
  @{ Dir = "rabbitmq-sample"; Image = "csharp-rabbitmq-sample:local" }
)

foreach ($s in $samples) {
  $dir = Join-Path $ROOT $s.Dir
  $image = $s.Image

  Write-Host ""
  Write-Host "==== Building $image from $dir ====" -ForegroundColor Cyan

  Push-Location $dir
  docker build -t $image .
  Pop-Location

  & "$PSScriptRoot\docker-save-load-to-minikube.ps1" -Image $image
}

docker exec minikube docker images | Select-String "csharp-.*-sample"
