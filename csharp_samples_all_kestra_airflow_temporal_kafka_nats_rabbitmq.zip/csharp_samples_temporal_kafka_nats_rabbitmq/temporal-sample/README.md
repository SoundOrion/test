# C# Temporal sample

Temporal Server が minikube 上の `temporal` namespace に起動済みである前提の C# サンプルです。

- worker: `TEMPORAL_MODE=worker` で Task Queue を poll
- starter: `TEMPORAL_MODE=start` で Workflow を開始し、完了まで待機

接続先:

```text
temporal-frontend.temporal.svc.cluster.local:7233
```

## build / load

```powershell
docker build -t csharp-temporal-sample:local .
..\scripts\docker-save-load-to-minikube.ps1 -Image csharp-temporal-sample:local
```

## apply

```powershell
& $KUBECTL --kubeconfig $KUBECONFIG_PATH apply -f ..\k8s\namespace.yaml
& $KUBECTL --kubeconfig $KUBECONFIG_PATH apply -f .\k8s\worker-deployment.yaml

# worker が起動してから starter job を投入
& $KUBECTL --kubeconfig $KUBECONFIG_PATH delete job -n app-sample csharp-temporal-starter --ignore-not-found
& $KUBECTL --kubeconfig $KUBECONFIG_PATH apply -f .\k8s\starter-job.yaml
```

## logs

```powershell
& $KUBECTL --kubeconfig $KUBECONFIG_PATH logs -n app-sample deploy/csharp-temporal-worker -f
& $KUBECTL --kubeconfig $KUBECONFIG_PATH logs -n app-sample job/csharp-temporal-starter
```
