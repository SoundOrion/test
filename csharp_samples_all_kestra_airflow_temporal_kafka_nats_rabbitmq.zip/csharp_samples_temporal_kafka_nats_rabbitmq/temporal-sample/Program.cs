using Temporalio.Activities;
using Temporalio.Client;
using Temporalio.Worker;
using Temporalio.Workflows;

using var cts = new CancellationTokenSource();
Console.CancelKeyPress += (_, e) =>
{
    e.Cancel = true;
    cts.Cancel();
};

var mode = Env("TEMPORAL_MODE", "worker").ToLowerInvariant();
var address = Env("TEMPORAL_ADDRESS", "temporal-frontend.temporal.svc.cluster.local:7233");
var ns = Env("TEMPORAL_NAMESPACE", "default");
var taskQueue = Env("TEMPORAL_TASK_QUEUE", "csharp-sample-task-queue");

Console.WriteLine($"TEMPORAL_MODE={mode}");
Console.WriteLine($"TEMPORAL_ADDRESS={address}");
Console.WriteLine($"TEMPORAL_NAMESPACE={ns}");
Console.WriteLine($"TEMPORAL_TASK_QUEUE={taskQueue}");

var client = await TemporalClient.ConnectAsync(new(address)
{
    Namespace = ns
});

switch (mode)
{
    case "worker":
        await RunWorkerAsync(client, taskQueue, cts.Token);
        break;

    case "start":
        await StartWorkflowAsync(client, taskQueue, cts.Token);
        break;

    default:
        throw new InvalidOperationException($"Unknown TEMPORAL_MODE: {mode}");
}

static async Task RunWorkerAsync(TemporalClient client, string taskQueue, CancellationToken ct)
{
    Console.WriteLine("Starting Temporal worker...");

    using var worker = new TemporalWorker(
        client,
        new TemporalWorkerOptions(taskQueue)
            .AddWorkflow<GreetingWorkflow>()
            .AddAllActivities(new GreetingActivities())
    );

    await worker.ExecuteAsync(ct);
}

static async Task StartWorkflowAsync(TemporalClient client, string taskQueue, CancellationToken ct)
{
    var name = Env("GREETING_NAME", "minikube");
    var workflowId = Env("TEMPORAL_WORKFLOW_ID", $"csharp-greeting-{DateTimeOffset.UtcNow:yyyyMMddHHmmss}");

    Console.WriteLine($"Starting workflow: workflowId={workflowId}, name={name}");

    var handle = await client.StartWorkflowAsync(
        (GreetingWorkflow wf) => wf.RunAsync(name),
        new(id: workflowId, taskQueue: taskQueue)
    );

    var result = await handle.GetResultAsync(cancellationToken: ct);
    Console.WriteLine($"Workflow completed: result={result}");
}

[Workflow]
public class GreetingWorkflow
{
    [WorkflowRun]
    public async Task<string> RunAsync(string name)
    {
        var result = await Workflow.ExecuteActivityAsync(
            (GreetingActivities activities) => activities.SayHelloAsync(name),
            new ActivityOptions
            {
                StartToCloseTimeout = TimeSpan.FromSeconds(30),
                RetryPolicy = new()
                {
                    MaximumAttempts = 3
                }
            }
        );

        return result;
    }
}

public class GreetingActivities
{
    [Activity]
    public Task<string> SayHelloAsync(string name)
    {
        var message = $"Hello {name} from C# Temporal Activity at {DateTimeOffset.UtcNow:O}";
        Console.WriteLine(message);
        return Task.FromResult(message);
    }
}

static string Env(string name, string fallback)
{
    var value = Environment.GetEnvironmentVariable(name);
    return string.IsNullOrWhiteSpace(value) ? fallback : value;
}
