$BASE="C:\Users\Hatsuyama\Desktop\k8s\k8s-offline"
$MINIKUBE="C:\Users\Hatsuyama\Desktop\k8s\tools\minikube\minikube.exe"

$image="kestra-csharp-job-sample:local"

docker build -t $image .

# minikube image load が使える場合
& $MINIKUBE image load $image --profile=minikube

# 確認
Docker exec minikube docker images | Select-String "kestra-csharp-job-sample"
