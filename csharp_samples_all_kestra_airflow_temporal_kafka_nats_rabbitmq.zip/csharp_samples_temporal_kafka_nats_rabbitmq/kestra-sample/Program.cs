using System.Text.Json;

static string Env(string name, string fallback = "") =>
    string.IsNullOrWhiteSpace(Environment.GetEnvironmentVariable(name))
        ? fallback
        : Environment.GetEnvironmentVariable(name)!;

var message = Env("SAMPLE_MESSAGE", "hello from C# job launched by Kestra");
var executionId = Env("KESTRA_EXECUTION_ID", "unknown");
var shouldFail = bool.TryParse(Env("SAMPLE_FAIL", "false"), out var fail) && fail;
var stepCount = int.TryParse(Env("SAMPLE_STEPS", "5"), out var steps) ? steps : 5;
var delayMs = int.TryParse(Env("SAMPLE_DELAY_MS", "1000"), out var delay) ? delay : 1000;

Console.WriteLine("=== Kestra C# Job Sample started ===");
Console.WriteLine(JsonSerializer.Serialize(new
{
    message,
    executionId,
    machine = Environment.MachineName,
    timestamp = DateTimeOffset.UtcNow
}));

for (var i = 1; i <= stepCount; i++)
{
    Console.WriteLine($"step {i}/{stepCount}: processing...");
    await Task.Delay(delayMs);
}

if (shouldFail)
{
    Console.Error.WriteLine("SAMPLE_FAIL=true was set. Exiting with failure code 2.");
    Environment.Exit(2);
}

Console.WriteLine("=== Kestra C# Job Sample completed ===");
