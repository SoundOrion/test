# C# NATS sample

NATS が minikube 上の `nats` namespace に起動済みである前提の C# publish / subscribe サンプルです。

接続先:

```text
nats://nats.nats.svc.cluster.local:4222
```

## build / load

```powershell
docker build -t csharp-nats-sample:local .
..\scripts\docker-save-load-to-minikube.ps1 -Image csharp-nats-sample:local
```

## apply

```powershell
& $KUBECTL --kubeconfig $KUBECONFIG_PATH apply -f ..\k8s\namespace.yaml
& $KUBECTL --kubeconfig $KUBECONFIG_PATH apply -f .\k8s\subscriber-deployment.yaml

& $KUBECTL --kubeconfig $KUBECONFIG_PATH delete job -n app-sample csharp-nats-publisher --ignore-not-found
& $KUBECTL --kubeconfig $KUBECONFIG_PATH apply -f .\k8s\publisher-job.yaml
```

## logs

```powershell
& $KUBECTL --kubeconfig $KUBECONFIG_PATH logs -n app-sample deploy/csharp-nats-subscriber -f
& $KUBECTL --kubeconfig $KUBECONFIG_PATH logs -n app-sample job/csharp-nats-publisher
```
