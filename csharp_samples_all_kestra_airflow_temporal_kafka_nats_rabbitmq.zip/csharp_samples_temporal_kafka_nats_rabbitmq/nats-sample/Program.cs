using NATS.Client.Core;

using var cts = new CancellationTokenSource();
Console.CancelKeyPress += (_, e) =>
{
    e.Cancel = true;
    cts.Cancel();
};

var mode = Env("NATS_MODE", "publish").ToLowerInvariant();
Console.WriteLine($"NATS_MODE={mode}");

switch (mode)
{
    case "publish":
        await PublishAsync(cts.Token);
        break;

    case "subscribe":
        await SubscribeAsync(cts.Token);
        break;

    default:
        throw new InvalidOperationException($"Unknown NATS_MODE: {mode}");
}

static async Task PublishAsync(CancellationToken ct)
{
    var url = Env("NATS_URL", "nats://nats.nats.svc.cluster.local:4222");
    var subject = Env("NATS_SUBJECT", "test.subject");
    var payload = Env("NATS_PAYLOAD", $"hello from C# NATS at {DateTimeOffset.UtcNow:O}");

    await using var nats = new NatsClient(new NatsOpts
    {
        Url = url
    });

    await nats.PublishAsync<string>(
        subject: subject,
        data: payload,
        cancellationToken: ct
    );

    Console.WriteLine($"NATS published: url={url}, subject={subject}, payload={payload}");
}

static async Task SubscribeAsync(CancellationToken ct)
{
    var url = Env("NATS_URL", "nats://nats.nats.svc.cluster.local:4222");
    var subject = Env("NATS_SUBJECT", "test.subject");

    await using var nats = new NatsClient(new NatsOpts
    {
        Url = url
    });

    Console.WriteLine($"NATS subscribing: url={url}, subject={subject}");

    await foreach (var msg in nats.SubscribeAsync<string>(subject).WithCancellation(ct))
    {
        Console.WriteLine($"NATS received: subject={msg.Subject}, data={msg.Data}");
    }
}

static string Env(string name, string fallback)
{
    var value = Environment.GetEnvironmentVariable(name);
    return string.IsNullOrWhiteSpace(value) ? fallback : value;
}
