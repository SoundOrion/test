$MINIKUBE="C:\Users\Hatsuyama\Desktop\k8s\tools\minikube\minikube.exe"

$image="airflow-csharp-job-sample:local"

docker build -t $image .
& $MINIKUBE image load $image --profile=minikube

docker exec minikube docker images | Select-String "airflow-csharp-job-sample"
