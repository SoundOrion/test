$HELM="C:\Users\Hatsuyama\Desktop\k8s\tools\helm\helm.exe"
$MINIKUBE="C:\Users\Hatsuyama\Desktop\k8s\tools\minikube\minikube.exe"
$KUBECONFIG_PATH="C:\Users\Hatsuyama\Desktop\k8s\kube\config"

$imageRepo="airflow-with-dags"
$imageTag="3.2.2-csharp-v1"

# airflow-sample ディレクトリで実行する想定
Copy-Item -Recurse -Force .\dags .\airflow-image\dags
Push-Location .\airflow-image

docker build -t ${imageRepo}:${imageTag} .
& $MINIKUBE image load ${imageRepo}:${imageTag} --profile=minikube

Pop-Location

& $HELM --kubeconfig $KUBECONFIG_PATH upgrade --install airflow .\charts\airflow-1.22.0.tgz `
  --namespace airflow `
  --reuse-values `
  --set images.airflow.repository=$imageRepo `
  --set images.airflow.tag=$imageTag `
  --set images.airflow.pullPolicy=Never `
  --timeout 60m
