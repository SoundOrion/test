import datetime

from airflow.sdk import dag
from airflow.providers.cncf.kubernetes.operators.pod import KubernetesPodOperator


@dag(
    dag_id="run_csharp_k8s_pod",
    start_date=datetime.datetime(2024, 1, 1),
    schedule=None,
    catchup=False,
    tags=["local", "csharp", "kubernetes"],
)
def run_csharp_k8s_pod():
    KubernetesPodOperator(
        task_id="run_csharp",
        name="airflow-csharp-job-sample",
        namespace="app-sample",
        image="airflow-csharp-job-sample:local",
        image_pull_policy="IfNotPresent",
        in_cluster=True,
        get_logs=True,
        is_delete_operator_pod=True,
        env_vars={
            "SAMPLE_MESSAGE": "hello from Airflow and C#",
            "SAMPLE_FAIL": "false",
            "SAMPLE_STEPS": "5",
            "SAMPLE_DELAY_MS": "1000",
            "AIRFLOW_DAG_ID": "{{ dag.dag_id }}",
            "AIRFLOW_RUN_ID": "{{ run_id }}",
            "AIRFLOW_TASK_ID": "{{ task.task_id }}",
        },
    )


run_csharp_k8s_pod()
