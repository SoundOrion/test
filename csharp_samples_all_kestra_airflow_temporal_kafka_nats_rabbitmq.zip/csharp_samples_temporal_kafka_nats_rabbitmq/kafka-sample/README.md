# C# Kafka sample

Kafka が minikube 上の `kafka` namespace に起動済みである前提の C# producer / consumer サンプルです。

接続先の候補:

```text
kafka.kafka.svc.cluster.local:9092
kafka-controller.kafka.svc.cluster.local:9092
```

Service 名は環境に合わせて `KAFKA_BOOTSTRAP_SERVERS` を変更してください。

## build / load

```powershell
docker build -t csharp-kafka-sample:local .
..\scripts\docker-save-load-to-minikube.ps1 -Image csharp-kafka-sample:local
```

## apply

```powershell
& $KUBECTL --kubeconfig $KUBECONFIG_PATH apply -f ..\k8s\namespace.yaml
& $KUBECTL --kubeconfig $KUBECONFIG_PATH apply -f .\k8s\consumer-deployment.yaml

& $KUBECTL --kubeconfig $KUBECONFIG_PATH delete job -n app-sample csharp-kafka-producer --ignore-not-found
& $KUBECTL --kubeconfig $KUBECONFIG_PATH apply -f .\k8s\producer-job.yaml
```

## logs

```powershell
& $KUBECTL --kubeconfig $KUBECONFIG_PATH logs -n app-sample deploy/csharp-kafka-consumer -f
& $KUBECTL --kubeconfig $KUBECONFIG_PATH logs -n app-sample job/csharp-kafka-producer
```
