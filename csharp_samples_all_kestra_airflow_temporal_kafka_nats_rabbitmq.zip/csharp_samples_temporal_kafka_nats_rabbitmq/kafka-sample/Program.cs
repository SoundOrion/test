using Confluent.Kafka;

using var cts = new CancellationTokenSource();
Console.CancelKeyPress += (_, e) =>
{
    e.Cancel = true;
    cts.Cancel();
};

var mode = Env("KAFKA_MODE", "produce").ToLowerInvariant();
Console.WriteLine($"KAFKA_MODE={mode}");

switch (mode)
{
    case "produce":
        await ProduceAsync(cts.Token);
        break;

    case "consume":
        Consume(cts.Token);
        break;

    default:
        throw new InvalidOperationException($"Unknown KAFKA_MODE: {mode}");
}

static async Task ProduceAsync(CancellationToken ct)
{
    var bootstrapServers = Env("KAFKA_BOOTSTRAP_SERVERS", "kafka.kafka.svc.cluster.local:9092");
    var topic = Env("KAFKA_TOPIC", "test-topic");
    var key = Env("KAFKA_KEY", Environment.MachineName);
    var value = Env("KAFKA_VALUE", $"hello from C# Kafka at {DateTimeOffset.UtcNow:O}");

    var config = new ProducerConfig
    {
        BootstrapServers = bootstrapServers,
        ClientId = "csharp-kafka-sample"
    };

    using var producer = new ProducerBuilder<string, string>(config).Build();

    var result = await producer.ProduceAsync(
        topic,
        new Message<string, string>
        {
            Key = key,
            Value = value
        },
        ct
    );

    Console.WriteLine($"Kafka produced: {result.TopicPartitionOffset}, key={key}, value={value}");
}

static void Consume(CancellationToken ct)
{
    var bootstrapServers = Env("KAFKA_BOOTSTRAP_SERVERS", "kafka.kafka.svc.cluster.local:9092");
    var topic = Env("KAFKA_TOPIC", "test-topic");
    var groupId = Env("KAFKA_GROUP_ID", "csharp-kafka-sample");

    var config = new ConsumerConfig
    {
        BootstrapServers = bootstrapServers,
        GroupId = groupId,
        AutoOffsetReset = AutoOffsetReset.Earliest,
        EnableAutoCommit = true
    };

    using var consumer = new ConsumerBuilder<string, string>(config).Build();
    consumer.Subscribe(topic);

    Console.WriteLine($"Kafka consuming: bootstrapServers={bootstrapServers}, topic={topic}, groupId={groupId}");

    try
    {
        while (!ct.IsCancellationRequested)
        {
            var cr = consumer.Consume(ct);
            Console.WriteLine($"Kafka received: {cr.TopicPartitionOffset}, key={cr.Message.Key}, value={cr.Message.Value}");
        }
    }
    catch (OperationCanceledException)
    {
        Console.WriteLine("Kafka consumer canceled.");
    }
    finally
    {
        consumer.Close();
    }
}

static string Env(string name, string fallback)
{
    var value = Environment.GetEnvironmentVariable(name);
    return string.IsNullOrWhiteSpace(value) ? fallback : value;
}
